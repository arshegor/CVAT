
# Copyright (C) 2018 Intel Corporation
#
# SPDX-License-Identifier: MIT

from django.apps import AppConfig


class DocumentationConfig(AppConfig):
    name = 'cvat.apps.documentation'

