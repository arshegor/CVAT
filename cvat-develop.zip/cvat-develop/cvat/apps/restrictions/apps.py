# Copyright (C) 2020 Intel Corporation
#
# SPDX-License-Identifier: MIT


from django.apps import AppConfig


class RestrictionsConfig(AppConfig):
    name = 'cvat.apps.restrictions'
