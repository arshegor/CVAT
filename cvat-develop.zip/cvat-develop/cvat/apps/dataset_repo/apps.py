# Copyright (C) 2018 Intel Corporation
#
# SPDX-License-Identifier: MIT

from django.apps import AppConfig


class GitConfig(AppConfig):
    name = 'dataset_repo'
