from django.apps import AppConfig


class LogViewerConfig(AppConfig):
    name = 'log_viewer'
