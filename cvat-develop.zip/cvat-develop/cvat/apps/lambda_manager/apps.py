from django.apps import AppConfig


class LambdaManagerConfig(AppConfig):
    name = 'lambda_manager'
