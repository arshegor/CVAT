# Copyright (C) 2018 Intel Corporation
#
# SPDX-License-Identifier: MIT

default_app_config = 'cvat.apps.engine.apps.EngineConfig'
