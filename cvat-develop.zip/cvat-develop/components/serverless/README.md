## Serverless for Computer Vision Annotation Tool (CVAT)

### Run docker container

```bash
# From project root directory
docker-compose -f docker-compose.yml -f components/serverless/docker-compose.serverless.yml up -d
```
